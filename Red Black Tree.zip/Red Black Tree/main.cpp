#include <iostream>

using namespace std;

enum Color{BLACK,RED};

class Node
{
    public:
        int key;
        bool color;
        Node *left, *right, *parent;
        Node (int data)
        {
            this->key = data;
            left = right = parent = NULL;
            this->color = RED;
        }
};

class RBTree
{
    private:
        Node *root;
    protected:
        void LeftRotate(Node*& root,Node*& node);
        void RightRotate(Node*& root, Node*& node);
        void Check(Node*& root, Node*& newNode);
    public:
        RBTree(){root = NULL;}
        void RBInsert(const int &key);
        void inorder();
};

Node* Insert(Node* root,Node* node)
{
    if(root == NULL)
    {
        return node;
    }
    if(node->key > root->key)
    {
        root->right = Insert(root->right,node);
        root->right->parent = root;
    }
    else
    {
        root->left = Insert(root->left,node);
        root->left->parent = root;
    }
    return root;
}


void RBTree::LeftRotate(Node*& root,Node*& node)
{
	Node *parent = node->parent;
	Node *node_right_temp = node->right;
	bool P_is_left;
	bool P_is_root = false;
	if (parent == root) P_is_root = true;                      //To check if the parent is root
	else if(parent->parent->left == parent) P_is_left == true;     //Parent is the left child
	else P_is_left == false;                               //Parent is the right child

	node->right = parent;
	if (P_is_root == false)
	{
		node->parent = parent->parent;
		if(P_is_left == true) parent->parent->left = node;    //assign the GP's left child is the new parent
		else parent->parent->right = node;					 //assign the GP's right child is the new parent
	}
	else
	{
		node->parent = NULL;
		root = node;				//after rotation the node is the new root
	}
	parent->parent = node;
	if(node_right_temp != NULL)
	{
		parent->left = node_right_temp;
		parent->left->parent = parent;
	}
    /*cout<<"("<<root->key<<","<<root->color<<")"<<" ";
    cout<<"("<<root->left->key<<","<<root->left->color<<")"<<" ";
    cout<<"("<<root->right->key<<","<<root->right->color<<")"<<" ";*/
}


void RBTree::RightRotate(Node*& root,Node*& node)
{
	Node *parent = node->parent;
	Node *node_left_temp = node->left;
	bool P_is_left;
	bool P_is_root = false;
	if (parent == root) P_is_root = true;                      //To check if the parent is root
	else if(parent->parent->left == parent) P_is_left == true;     //Parent is the lef child
	else P_is_left == false;                               //Parent is the right child

	node->left = parent;
	if (P_is_root == false)
	{
		node->parent = parent->parent;
		if(P_is_left == true) parent->parent->left = node;    //assign the GP's left child is the new parent
		else parent->parent->right = node;					 //assign the GP's right child is the new parent
	}
	else
	{
		node->parent = NULL;
		root = node;				//after rotation the node is the new root
	}
	parent->parent = node;
	if(node_left_temp != NULL)
	{
		parent->right = node_left_temp;
		parent->right->parent = parent;
	}
    /*cout<<"Right Rotate"<<endl;
	cout<<"Node is "<<node->key<<endl;
	cout<<"Parent is "<<parent->key<<endl;*/
}


void RBTree::Check(Node*& root, Node*& node)
{
	Node* parent = NULL;
	Node* GP = NULL;
	while (node!=root && node->parent->color==RED && node->color==RED)
	{
		parent = node->parent;
		GP = node->parent->parent;
		if(GP->left == parent)
		{
			Node* Uncle = GP->right;
			if(Uncle!=NULL && Uncle->color==RED)    //Then Recoloring
			{
				parent->color = BLACK;
				Uncle->color = BLACK;
				GP->color = RED;
				node = GP;
			}
			else
			{
				if(parent->right == node)
				{
					RightRotate(root,node);
					Node* temp = node;
					node = parent;
					parent = temp;
				}
				LeftRotate(root,parent);
				parent->color = BLACK;
				GP->color = RED;
				node = GP;
			}
		}
		else
		{
			Node* Uncle = GP->left;
			if(Uncle!=NULL && Uncle->color==RED)    //Then Recoloring
			{
				parent->color = BLACK;
				Uncle->color = BLACK;
				GP->color = RED;
				node = GP;
			}
			else
			{
				if(parent->left == node)
				{
					LeftRotate(root,node);
					Node* temp = node;
					node = parent;
					parent = temp;
				}
				RightRotate(root,parent);
				parent->color = BLACK;
				GP->color = RED;
				node = GP;
			}
		}
	}
	root->color = BLACK;
}

void RBTree::RBInsert (const int &key)
{
    Node* newNode = new Node(key);
    root = Insert(root,newNode);
    Check(root,newNode);
}




int num=0;

void PrintInorder(Node *root){
    //cout<<endl<<"("<<root->key<<","<<root->color<<")"<<" ";
    /*cout<<"("<<root->left->key<<","<<root->left->color<<")"<<" ";
    cout<<"("<<root->right->key<<","<<root->right->color<<")"<<" ";*/
    if(root == NULL)
    {
        return;
    }
    PrintInorder(root->left);
    cout<<"("<<root->key<<","<<root->color<<")"<<" ";
    PrintInorder(root->right);
}

void RBTree::inorder(){PrintInorder(root);} //we make another inorder because root is private and we cannot call it in main for the normal printInorder so we create an alternative for it

int main()
{
    RBTree tree;
    tree.RBInsert(7);
    tree.RBInsert(6);
    tree.RBInsert(5);
    /*tree.RBInsert(4);
    tree.RBInsert(3);
    tree.RBInsert(2);
    tree.RBInsert(1);*/
    tree.inorder();
    return 0;
}
