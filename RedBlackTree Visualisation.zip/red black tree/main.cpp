#if defined(UNICODE) && !defined(_UNICODE)
    #define _UNICODE
#elif defined(_UNICODE) && !defined(UNICODE)
    #define UNICODE
#endif
#include <tchar.h>
#include <windows.h>
#include <iostream>
#include<stack>
#include<charconv>
#include<string>
using namespace std;
class Node
{
public:
    int key;
    Node * p;
    Node * l;
    Node * r;
    bool color;
    Node (int k,Node* r=NULL,Node*l=NULL,Node*p=NULL,bool color=1)//red=1,black=0
    {
        this->key=k;
        this->p=p;
        this->r=r;
        this->l=l;
        this->color=color;
    }
    Node* operator[](int i)
    {
        Node *r=this;
        stack<bool> direction;
        while(i>0)
        {
            direction.push(i&2);
            i=int((i-1)/2);
        }
        while(!direction.empty())
        {
            if(r==NULL)break;
            bool d=direction.top();
            if(d)
                r=r->r;
            else
                r=r->l;
            direction.pop();
        }
        return r;
    }
};
void inorderPrint(Node*root)
{
    if(root==NULL)return;
    inorderPrint(root->l);
    cout<<root->key<<" : "<<root->color<<endl;
    inorderPrint(root->r);
}
Node*& insertNode(int key,Node*&root,Node * p=NULL)
{
    if (root==NULL)
    {
        root=new Node(key,NULL,NULL,p);
        return root;
    }
    if(key < root->key)
        return insertNode(key,root->l,root);
    else
        return insertNode(key,root->r,root);
}
void rightRotate(Node*& root)
{
    if(root->l==NULL)return;
    Node *p=root->p;
    Node *y=root;
    Node *x=y->l;
    Node *b=x->r;
    root=x;
    x->p=p;
    y->p=x;
    x->r=y;
    if(b!=NULL)
        b->p=y;
    y->l=b;
}
void leftRotate(Node*& root)
{
    if(root->r==NULL)return;
    Node *p=root->p;
    Node *x=root;
    Node *y=x->r;
    Node *b=y->l;
    root=y;
    y->p=p;
    y->l=x;
    x->p=y;
    if(b!=NULL)
        b->p=x;
    x->r=b;
}
void insertRBNode(int key,Node*&root)
{
    Node* x=insertNode(key,root);
    while(x->p!=root&&x!=root)
    {
        Node* parent=x->p;
        if(parent->color==0)
            break;

        if(parent==parent->p->l)
        {
            Node* uncle=parent->p->r;
            if(uncle!=NULL && uncle->color==1)
            {
                parent->color=0;
                uncle->color=0;
                parent->p->color=1;
                x=parent->p;
            }
            else
            {
                if(x==parent->r)
                {
                    leftRotate(parent->p->l);
                    x=parent;
                }
                else
                {
                    parent->color=0;
                    parent->p->color=1;
                    Node* rp=parent->p;
                    if(rp==root)
                        rightRotate(root);
                    else
                    {
                        if(rp==rp->p->r)
                            rightRotate(rp->p->r);
                        else
                            rightRotate(rp->p->l);
                    }

                }
            }
        }
        else
        {
            Node* uncle=parent->p->l;
            if(uncle!=NULL && uncle->color==1)
            {
                parent->color=0;
                uncle->color=0;
                parent->p->color=1;
                x=parent->p;
            }
            else
            {
                if(x==parent->l)
                {
                    rightRotate(parent->p->r);
                    x=parent;
                }
                else
                {
                    parent->color=0;
                    parent->p->color=1;
                    Node* rp=parent->p;
                    if(rp==root)
                        leftRotate(root);
                    else
                    {
                        if(rp==rp->p->r)
                            leftRotate(rp->p->r);
                        else
                            leftRotate(rp->p->l);
                    }

                }
            }

        }
    }
    root->color=0;
}
Node *&searchNode(Node *& root,int key)
{
    if(root==NULL||root->key==key)
        return root;
    else if(root->key<key)
        return searchNode(root->r,key);
    else
        return searchNode(root->l,key);
}
Node *& sucessor(Node *& root)
{
    if(root==NULL)return root;
    Node* track=root;
    if(track->r!=NULL)
        track=track->r;
    else
        return track->r;
    if(track->l==NULL)return track->p->r;
    while(track->l!=NULL)
        track=track->l;
    return track->p->l;
}
Node*& deleteNode(Node*& dnode)
{
    if(dnode==NULL)return dnode;
    if(dnode->l==NULL &&dnode->r==NULL)return dnode;
    Node*&s=sucessor(dnode);
    if(s==NULL)
    {
        dnode->key=dnode->l->key;
        return dnode->l;
    }
    else
    {
        dnode->key=s->key;
        if(/*s->l==NULL &&*/ s->r==NULL)
            return s;
        else
        {
            return deleteNode(s);
        }
    }
}
void deleteRBNode(Node*&root,Node*& node)
{
    if(node==NULL)return;
    Node*& dnode=deleteNode(node);
    if(dnode->color==1)
    {
        delete[]dnode;
        dnode=NULL;
        return;
    }
    Node* dbnode=dnode;

    while(dbnode!=root)
    {
        if(dbnode==dbnode->p->l)
        {
            Node* parent=dbnode->p;
            Node* sibling=dbnode->p->r;
            Node *far_sibling_child=sibling->r;
            Node *near_sibling_child=sibling->l;
            if(sibling->color==0&&(far_sibling_child==NULL||far_sibling_child->color==0)&&(near_sibling_child==NULL||near_sibling_child->color==0))
            {
                sibling->color=1;
                if(parent->color==1)
                {
                    parent->color=0;
                    break;
                }
                else
                    dbnode=parent;
            }
            else if(sibling->color==1)
            {
                swap(parent->color,sibling->color);
                if(parent==root)
                    leftRotate(root);
                else
                {
                    if(parent==parent->p->l)
                        leftRotate(parent->p->l);
                    else
                        leftRotate(parent->p->r);
                }
            }
            else if(sibling->color==0&&near_sibling_child!=NULL&&near_sibling_child->color==1)
            {
                swap(sibling->color,near_sibling_child->color);
                rightRotate(parent->r);
            }
            else if(sibling->color==0&&far_sibling_child!=NULL&&far_sibling_child->color==1)
            {
                far_sibling_child->color=0;
                swap(parent->color,sibling->color);
                if(parent==root)
                    leftRotate(root);
                else
                {
                    if(parent==parent->p->l)
                        leftRotate(parent->p->l);
                    else
                        leftRotate(parent->p->r);
                }
                break;
            }
        }
        else
        {
            Node* parent=dbnode->p;
            Node* sibling=dbnode->p->l;
            Node *far_sibling_child=sibling->l;
            Node *near_sibling_child=sibling->r;
            if(sibling->color==0&&(far_sibling_child==NULL||far_sibling_child->color==0)&&(near_sibling_child==NULL||near_sibling_child->color==0))
            {
                sibling->color=1;
                if(parent->color==1)
                {
                    parent->color=0;
                    break;
                }
                else
                    dbnode=parent;
            }
            else if(sibling->color==1)
            {
                swap(parent->color,sibling->color);
                if(parent==root)
                    rightRotate(root);
                else
                {
                    if(parent==parent->p->l)
                        rightRotate(parent->p->l);
                    else
                        rightRotate(parent->p->r);
                }
            }
            else if(sibling->color==0&&near_sibling_child!=NULL&&near_sibling_child->color==1)
            {
                swap(sibling->color,near_sibling_child->color);
                leftRotate(parent->l);
            }
            else if(sibling->color==0&&far_sibling_child!=NULL&&far_sibling_child->color==1)
            {
                far_sibling_child->color=0;
                swap(parent->color,sibling->color);
                if(parent==root)
                    rightRotate(root);
                else
                {
                    if(parent==parent->p->l)
                        rightRotate(parent->p->l);
                    else
                        rightRotate(parent->p->r);
                }
                break;
            }
        }
    }
        delete[]dnode;
        dnode=NULL;
        return;
}
void clearNodes(Node*&root)
{
    while(root!=NULL)
        deleteRBNode(root,root);
}
/*  Declare Windows procedure  */
LRESULT CALLBACK WindowProcedure (HWND, UINT, WPARAM, LPARAM);

/*  Make the class name into a global variable  */
TCHAR szClassName[ ] = _T("CodeBlocksWindowsApp");

int WINAPI WinMain (HINSTANCE hThisInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR lpszArgument,
                     int nCmdShow)
{
    HWND hwnd;               /* This is the handle for our window */
    MSG messages;            /* Here messages to the application are saved */
    WNDCLASSEX wincl;        /* Data structure for the windowclass */

    /* The Window structure */
    wincl.hInstance = hThisInstance;
    wincl.lpszClassName = szClassName;
    wincl.lpfnWndProc = WindowProcedure;      /* This function is called by windows */
    wincl.style = CS_DBLCLKS;                 /* Catch double-clicks */
    wincl.cbSize = sizeof (WNDCLASSEX);

    /* Use default icon and mouse-pointer */
    wincl.hIcon = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hIconSm = LoadIcon (NULL, IDI_APPLICATION);
    wincl.hCursor = LoadCursor (NULL, IDC_ARROW);
    wincl.lpszMenuName = NULL;                 /* No menu */
    wincl.cbClsExtra = 0;                      /* No extra bytes after the window class */
    wincl.cbWndExtra = 0;                      /* structure or the window instance */
    /* Use Windows's default colour as the background of the window */
    wincl.hbrBackground = (HBRUSH) COLOR_BACKGROUND;

    /* Register the window class, and if it fails quit the program */
    if (!RegisterClassEx (&wincl))
        return 0;

    /* The class is registered, let's create the program*/
    hwnd = CreateWindowEx (
           0,                   /* Extended possibilites for variation */
           szClassName,         /* Classname */
           _T("Code::Blocks Template Windows App"),       /* Title Text */
           WS_OVERLAPPEDWINDOW, /* default window */
           CW_USEDEFAULT,       /* Windows decides the position */
           CW_USEDEFAULT,       /* where the window ends up on the screen */
           544,                 /* The programs width */
           375,                 /* and height in pixels */
           HWND_DESKTOP,        /* The window is a child-window to desktop */
           NULL,                /* No menu */
           hThisInstance,       /* Program Instance handler */
           NULL                 /* No Window Creation data */
           );

    /* Make the window visible on the screen */
    ShowWindow (hwnd, nCmdShow);

    /* Run the message loop. It will run until GetMessage() returns 0 */
    while (GetMessage (&messages, NULL, 0, 0))
    {
        /* Translate virtual-key messages into character messages */
        TranslateMessage(&messages);
        /* Send message to WindowProcedure */
        DispatchMessage(&messages);
    }

    /* The program return-value is 0 - The value that PostQuitMessage() gave */
    return messages.wParam;
}


/*  This function is called by the Windows function DispatchMessage()  */
void drawNode(HDC hdc,int x, int y,int r,int dx,int dy,int k,COLORREF color)
{
    HBRUSH hBrush = CreateSolidBrush (color) ;
    SelectObject (hdc, hBrush) ;
    Ellipse(hdc,x-r,y-r,x+r,y+r);
    int l=to_string(k).length();
    char* n=new char[l];
    to_chars(n,n+l,k);
    TextOut(hdc,x,y-7,n,l);
    delete[]n;
    DeleteObject (hBrush) ;
    MoveToEx(hdc,x,y+r,NULL);
    LineTo(hdc,x-(dx/2),y+r+dy);
    MoveToEx(hdc,x,y+r,NULL);
    LineTo(hdc,x+(dx/2),y+r+dy);
}
void drawTree(HDC hdc,Node* root,int x, int y,int r,int dx,int dy)
{
    if(root==NULL)return;
    drawTree(hdc,root->l,x-(dx/2),y+dy+(2*r),r,dx/2,dy);
    if(root->color)
        drawNode(hdc,x,y,r,dx,dy,root->key,RGB(255,0,0));
    else
        drawNode(hdc,x,y,r,dx,dy,root->key,RGB(0,0,0));
    drawTree(hdc,root->r,x+(dx/2),y+dy+(2*r),r,dx/2,dy);
}
Node* r=NULL;
LRESULT CALLBACK WindowProcedure (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    HDC hdc;
    PAINTSTRUCT ps;
    switch (message)                  /* handle the messages */
    {
        case WM_PAINT:
            hdc = BeginPaint (hwnd, &ps) ;
            drawTree(hdc,r,1000,50,30,500,60);
            EndPaint (hwnd, &ps) ;
            break;
        case WM_DESTROY:
            PostQuitMessage (0);       /* send a WM_QUIT to the message queue */
            break;
        case WM_LBUTTONDBLCLK:
            int k;
            cin>>k;
            insertRBNode(k,r);
            break;
        case WM_RBUTTONDBLCLK:
            int d;
            cin>>d;
            deleteNode(searchNode(r,d));
            break;
        case WM_KEYDOWN:
            switch(wParam)
            {
            case VK_DELETE:
                clearNodes(r);
                break;
            case VK_RETURN:
                inorderPrint(r);
                break;
            }
            break;
        default:                      /* for messages that we don't deal with */
            return DefWindowProc (hwnd, message, wParam, lParam);
    }

    return 0;
}
